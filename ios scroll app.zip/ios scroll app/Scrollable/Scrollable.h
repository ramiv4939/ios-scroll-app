//
//  Scrollable.h
//  Scrollable
//
//  Created by Evgenii on 25/06/2015.
//  Copyright © 2015 The Exchange Group Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Scrollable.
FOUNDATION_EXPORT double ScrollableVersionNumber;

//! Project version string for Scrollable.
FOUNDATION_EXPORT const unsigned char ScrollableVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Scrollable/PublicHeader.h>


